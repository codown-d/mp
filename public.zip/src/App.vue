<script setup>
import { RouterLink, RouterView } from 'vue-router'
import HelloWorld from './components/HelloWorld.vue'
</script>

<template>



  <RouterView />
</template>

<style scoped>
.{
  margin: 0;
  padding: 0;
}

</style>
